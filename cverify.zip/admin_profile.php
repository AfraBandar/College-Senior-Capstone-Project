<?php
include "template/header.php";
if(!isset($_SESSION['type'])){
    header('location:index.php');
    exit();
}
$table = $_SESSION['type'];
$table_id = 'adminid';
if($_SESSION['type'] == 'holder'){
    $table_id = 'holderid';
}elseif ($_SESSION['type'] == 'institute'){
    $table_id = 'instituteid';
}
$id = $_SESSION['user_id'];

if(isset($_POST['update'])){
    $errors = array();
    if($table == 'holder') {
        $fields = array('السجل المدني'=>'holderid','الإسم' => 'name', 'الجوال' => 'mobile', 'البريد الالكتروني' => 'email',  'تاريخ الميلاد' => 'birthdate');
    }elseif($table == 'institute'){
        $fields = array('الإسم' => 'name', 'الجوال' => 'mobile', 'البريد الالكتروني' => 'email');
    }else{
        $fields = array('الإسم' => 'name', 'الجوال' => 'mobile', 'البريد الالكتروني' => 'email');
    }
    foreach ($fields as $key=>$field){
        if(!isset($_POST[$field]) || empty(trim($_POST[$field]))){
            $errors[$field] = " حقل $key الزامي";
        }
    }
    $name = mysqli_real_escape_string($conn,trim($_POST['name']));



    //check mobile
    if(isset($_POST['mobile']) && !empty(trim($_POST['mobile']))){
        $mobile = mysqli_real_escape_string($conn,trim($_POST['mobile']));
        if(! check_mobile($mobile)){
            $errors['mobile'] = 'رقم الهاتف يجب يحتوي على ارقام فقط';
        }elseif(strlen($mobile) != 10){
            $errors['mobile'] = 'رقم الهاتف يجب يحتوي على 10 خانات فقط';
        }elseif(! check_mobile_exist($mobile,$table,$id,$table_id)){
            $errors['mobile'] = 'رقم الهاتف موجود مسبقا';
        }
    }

    //check if exist
    if (isset($_POST['username']) && !empty(trim($_POST['username']))) {
        $username = mysqli_real_escape_string($conn, trim($_POST['username']));
        if (!check_user_exist($username, $table,$id,$table_id)) {
            $errors['username'] = 'اسم المستخدم موجود مسبقا';
        }elseif (strlen($username) > 30){
            $errors['username'] = 'اسم المستخدم يجب ان لا يزيد عن 30 حرف';
        }
    }

    //validation email
    if(isset($_POST['email']) && !empty(trim($_POST['email']))){
        $email = mysqli_real_escape_string($conn,trim($_POST['email']));
        if(! check_email_exist($email,$table,$id,$table_id)){
            $errors['email'] = 'البريد الالكتروني موجود مسبقا';
        }elseif(! valid_email($email)){
            $errors['email'] = 'البريد الالكتروني غير صالح';
        }
    }
    if($table == 'institute'){
        $filename = '';
        if(! empty($_FILES['picture']['name'])){
            $tmp_file=$_FILES['picture']['tmp_name'];
            $filename=$_FILES['picture']['name'];
            $ext = explode('.',$filename);
            $extention = end($ext);
            $filename = str_replace(' ', '_', $filename);
            $filename = date('Ymdis').'.'.$extention;
            $upload="images/";
            if(($_FILES['picture']['type']=='image/jpeg')|| ($_FILES['picture']['type']=='image/jpg') || ($_FILES['picture']['type']=='image/png') ){
                if(empty($errors)){
                    if((move_uploaded_file($tmp_file, $upload.$filename))==1){

                    }
                }
                else{
                }
            }else{
                $form =0;
                $errors['image_re'] = 'امتداد الصورة يجب ان يكون  (jpeg,jpg,png)';
            }
        }
    }elseif($table == 'holder'){
        $dateNow = date('Y-m-d');
        if(isset($_POST['birthdate']) && !empty(trim($_POST['birthdate']))){
            $birthdate = mysqli_real_escape_string($conn, trim($_POST['birthdate']));
            $checkDateArr = explode('-',$birthdate);
            if(count($checkDateArr) != 3){
                $errors['birthDate'] = 'يرجى التحقق من تاريخ الميلاد';
            }else{
                if(!checkdate($checkDateArr[1],$checkDateArr[2],$checkDateArr[0])){
                    $errors['birthDate'] = 'يرجى التحقق من تاريخ الميلاد';
                }else{
                    if($dateNow <= $birthdate){
                        $errors['birthDate'] = 'يرجى التحقق من تاريخ الميلاد';
                    }
                }
            }
        }


        //check holderid
        if (isset($_POST['holderid']) && !empty(trim($_POST['holderid']))) {
            $holderid = mysqli_real_escape_string($conn, trim($_POST['holderid']));
            if (!check_holder_exist($holderid, $table,$id,$table_id)) {
                $errors['holderId'] = 'السجل المدني موجود مسبقا';
            }elseif(! check_mobile($holderid)){
                $errors['holderId'] = 'السجل المدني يجب يحتوي على ارقام فقط';
            }elseif (strlen($holderid) != 10){
                $errors['holderId'] = 'السجل المدني يجب ان يحتوي على 10 ارقام';
            }
        }

    }


    if(empty($errors)){
        if($table == 'holder') {
            $sql = "update `$table` set `holderid`='$holderid',`name`='$name', birthdate = '$birthdate',`mobile`='$mobile',username='$username',`email`='$email' WHERE `$table_id`=$id";
        }elseif($table == 'institute'){
            if($filename == ''){
                $sql = "update `$table` set `name`='$name', `mobile`='$mobile',`email`='$email' ,username='$username' WHERE `$table_id`=$id";
            }else{
                $sql = "update `$table` set `name`='$name', `mobile`='$mobile',username='$username',`email`='$email',photo = '$filename' WHERE `$table_id`=$id";
            }
        }else{
            $sql = "update `$table` set `name`='$name',`mobile`='$mobile',username='$username',`email`='$email' WHERE `$table_id`=$id";
        }
        if ($conn->query($sql) == TRUE) {
            if($table == 'holder') {
                $_SESSION['user_id'] = $holderid;
            }
            $success = 'تم تعديل البيانات بنجاح';
        }else{
            echo $conn->error.'<br>';
            echo $sql;
        }
    }
}
$id = $_SESSION['user_id'];
include "template/navbar.php";
?>

<!-- Page Content -->
<div class="container">

    <div class="row">
        <!-- /.col-lg-3 -->
        <div class="col-lg-9" style="margin-top: 36px">
            <h3 class="title_form" style="text-align: center">الملف الشخصي</h3>
            <form action="" method="post" dir="rtl" style="text-align: right" enctype="multipart/form-data">
                <?php
                if(isset($errors)){
                    foreach ($errors as $error){ ?>
                        <div class="alert alert-danger">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>خطأ!</strong> <?php echo $error; ?>
                        </div>
                    <?php    }
                }
                ?>
                <?php
                if(isset($success)){
                    ?>
                    <div class="alert alert-success">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>صحيح!</strong> <?php echo $success; ?>
                    </div>
                    <?php
                }
                ?>
                <?php

                $sql = "select * from `$table` where `$table_id`=$id limit 1";
                $result = $conn->query($sql);
                if($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                ?>
                    <?php
                    if($_SESSION['type'] == 'holder'){
                        ?>
                        <div class="form-group">
                            <label for="mobile">السجل المدني</label>
                            <input type="text"  onkeypress="return isNumberKey(event)" maxlength="10" value="<?php if(isset($_POST['holderid'])){ echo $_POST['holderid'];}else{
                                echo $row['holderid'];
                            }?>" name="holderid" class="form-control">
                        </div>
                    <?php } ?>
                <div class="form-group">
                    <label for="exampleInputEmail1">الاسم</label>
                    <input type="text" maxlength="30" name="name" value="<?php if(isset($_POST['name'])){ echo $_POST['name'];}else{echo $row['name']; }?>" class="form-control">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">البريد الالكتروني</label>
                    <input type="email" maxlength="30" name="email" value="<?php if(isset($_POST['email'])){ echo $_POST['email'];}else{echo $row['email']; } ?>" class="form-control">
                </div>
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label for="mobile">الجوال</label>
                            <input type="text"  onkeypress="return isNumberKey(event)" maxlength="10" value="<?php if(isset($_POST['mobile'])){ echo $_POST['mobile'];}else{echo $row['mobile']; } ?>" name="mobile" class="form-control">
                        </div>
                    </div>
                    <?php
                    if($_SESSION['type'] == 'holder'){
                    ?>
                    <div class="col">
                        <div class="form-group">
                            <label>تاريخ الميلاد</label>
                            <input type="date"  value="<?php if(isset($_POST['birthdate'])){ echo $_POST['birthdate'];}else{echo $row['birthdate']; } ?>" name="birthdate" class="form-control" style="text-align: right">
                        </div>
                    </div>
                        <?php } ?>
                </div>
                <div class="form-group">
                    <label for="username">اسم المستخدم</label>
                    <input type="text" maxlength="15" name="username" value="<?php if(isset($_POST['username'])){ echo $_POST['username'];}else{ echo $row['username']; } ?>" class="form-control">
                </div>

                <?php if($_SESSION['type'] == 'institute'){ ?>
                    <div class="form-group">
                        <label >الصورة</label>
                        <input maxlength="100" type="file" name="picture" class="form-control" data-prompt-position="topLeft">
                        <img src="images/<?php echo $row['photo']; ?>" width="80px" height="80px">
                    </div>
                <?php } ?>

                <?php }} ?>
                <button type="submit" class="btn btn-primary" name="update">تعديل</button>
				<br>
				<a href="admin_password.php">تغيير كلمة المرور</a>
            </form>
        </div>
        <?php include "template/sidebare.php"; ?>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->
</div>
<!-- /.container -->

<?php include "template/footer.php"; ?>
