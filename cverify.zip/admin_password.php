<?php
include "template/header.php";
if(!isset($_SESSION['type'])){
    header('location:index.php');
    exit();
}
$table = $_SESSION['type'];
$table_id = 'adminid';
if($_SESSION['type'] == 'holder'){
    $table_id = 'holderid';
}elseif ($_SESSION['type'] == 'institute'){
    $table_id = 'instituteid';
}
$id = $_SESSION['user_id'];

if(isset($_POST['register'])){
    $errors = array();
    $fields = array('كلمة المرور الجديدة'=>'new_password','تأكيد كلمة المرور'=>'conf_password','كلمة المرور'=>'password');
    foreach ($fields as $key=>$field){
        if(!isset($_POST[$field]) || empty(trim($_POST[$field]))){
            $errors[$field] = " حقل $key الزامي";
        }
    }

    $password_conf = mysqli_real_escape_string($conn,trim($_POST['conf_password']));
    $password = mysqli_real_escape_string($conn,trim($_POST['new_password']));
    if (isset($_POST['new_password']) && !empty($_POST['new_password'])) {
        if (strlen($password) < 6) {
            $errors['new_password'] = 'كلمة المرور يجب ان لا تقل عن 6 حروف';
        }
    }

    if(empty($errors)){
        if($password != $password_conf){
            $errors['pass'] = "كلمة المرور غير متطابقة";
        }
    }

    $old_pass = mysqli_real_escape_string($conn,trim($_POST['password']));
    if(!empty($old_pass)) {
        $sqlCheck = "select * from `$table` WHERE password='$old_pass' and `$table_id`=$id";
        $resultC = $conn->query($sqlCheck);
        if ($resultC->num_rows <= 0) {
            $errors['old'] = 'يرجى التحقق من كلمة المرور القديمة';
        }
    }
    if(empty($errors)){
        $sql = "UPDATE  `$table` set 
            `password`='$password' Where `$table_id`=$id
            ";
        if ($conn->query($sql) == TRUE) {
            $success = 'تم تغيير كلمة المورور بنجاح';
        }else{
            echo $conn->error.'<br>';
            echo $sql;
        }
    }
}

include "template/navbar.php";
?>

<!-- Page Content -->
<div class="container">

    <div class="row">
        <!-- /.col-lg-3 -->
        <div class="col-lg-9" style="margin-top: 36px">
            <h3 class="title_form" style="text-align: center">تغيير كلمة المرور</h3>
            <form action="" method="post"  style="text-align: right" dir="rtl">

                <div class="">
                    <?php
                    if(isset($errors)){
                        foreach ($errors as $error){ ?>
                            <div class="alert alert-danger">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong>خطأ!</strong> <?php echo $error; ?>
                            </div>
                        <?php    }
                    }
                    ?>
                    <?php
                    if(isset($success)){
                        ?>
                        <div class="alert alert-success">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>صحيح!</strong> <?php echo $success; ?>
                        </div>
                        <?php
                    }
                    ?>
                    <div class="form-group">
                        <label for="inputEmail">كلمة المرور</label>
                        <input maxlength="20" class="form-control validate[required,custom[password]]" data-prompt-position="topLeft"
                               data-parsley-trigger="change" type="password" name="password"
                               value="" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label for="inputEmail">كلمة المرور الجديدة</label>
                        <input maxlength="20" class="form-control validate[required,custom[password]]" data-prompt-position="topLeft"
                               data-parsley-trigger="change" type="password" name="new_password"
                               value="" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label for="inputEmail">تأكيد كلمة المرور الجديدة</label>
                        <input maxlength="20" class="form-control validate[required,equals[password]]" data-prompt-position="topLeft"
                               data-parsley-trigger="change" type="password" name="conf_password"
                               value="" autocomplete="off">
                    </div>
                <button type="submit" name="register" class="btn btn-primary">حفظ</button>

                </div>
            </form>
        </div>
        <?php include "template/sidebare.php"; ?>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->
</div>
<!-- /.container -->

<?php include "template/footer.php"; ?>
