<?php
function get_type(){
    return [
        'بكالوريوس',
        'ماجستير',
		'دكتوراه',
		'دبلوم',
		'دورة تدريبية',

    ];
}
function getNameRand($n) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';

    for ($i = 0; $i < $n; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }

    return $randomString;
}
function valid_email($str) {
    return (!preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+(com)$/ix", $str)) ? FALSE : TRUE;
}

function check_holder_exist($holderId,$table,$id=0,$table_id = 'id'){
    global $conn;
    if($id == 0) {
        $sql = "select * FROM `$table`  where holderid='$holderId' ";
    }else{
        $sql = "select * FROM `$table`  where holderid='$holderId' and `$table_id` != $id ";
    }
    $result = $conn->query($sql);
    if($result->num_rows > 0) {
        return false;
    }
    return true;
}

function check_user_exist($username,$table,$id=0,$table_id = 'id'){
    global $conn;
    if($id == 0) {
        $sql = "select * FROM `$table`  where username='$username' ";
    }else{
        $sql = "select * FROM `$table`  where username='$username' and `$table_id` != $id ";
    }
    $result = $conn->query($sql);
    if($result->num_rows > 0) {
        return false;
    }
    return true;
}
function check_mobile_exist($mobile,$table,$id=0,$table_id = 'id'){
    global $conn;
    if($id == 0) {
        $sql = "select * FROM `$table`  where mobile='$mobile'";
    }else{
        $sql = "select * FROM `$table`  where mobile='$mobile' and `$table_id` != $id";
    }
    $result = $conn->query($sql);
    if($result->num_rows > 0) {
        return false;
    }
    return true;
}
function check_email_exist($email,$table,$id=0,$table_id = 'id'){
    global $conn;
    if($id == 0) {
        $sql = "select * FROM `$table`  where email='$email'";
    }else{
        $sql = "select * FROM `$table`  where email='$email' and `$table_id` != $id";
    }
    $result = $conn->query($sql);
    if($result->num_rows > 0) {
        return false;
    }
    return true;
}

function check_email_validation($email){
    return (!preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+(com)$/ix", $email)) ? FALSE : TRUE;
}

function check_mobile($mobile){
    if(is_numeric($mobile))
        return true;
    return false;
}


