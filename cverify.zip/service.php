<?php
include "template/header.php";
if(isset($_POST['login'])){
    if(!isset($_POST['holderid']) || empty($_POST['holderid'])){
        $errors['holderid'] = 'يرجى ادخال رقم الشهادة للتحقق من الشهادة';
    }else{
        $holderId = mysqli_real_escape_string($conn, trim($_POST['holderid']));
        //die($holderId);
    }
    if(empty($errors)){
        $sql = "select * from certificate where serial_code='$holderId' limit 1";
        $result = $conn->query($sql);
        if($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $serial = $row['serial_code'] ;
                header("location:certificate_general.php?id=$serial");
                exit();
            }
        }else{
            $errors['holderid'] = 'رقم الشهادة غير صالح يرجى التحقق من الرقم المدخل';
        }
    }
}
include "template/navbar.php";
?>

<!-- Page Content -->
<div class="container">

    <div class="row mt-5">
        <div class="col-lg-3"></div>
        <div class="col-lg-6" dir="rtl" style="text-align: right">
            <h3 class="title_form" style="text-align: center">التحقق من الشهادة</h3>
            <form action="" method="post" id="form1">
                <?php
                if(isset($errors)){
                    foreach ($errors as $error){ ?>
                        <div class="alert alert-danger">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>خطأ!</strong> <?php echo $error; ?>
                        </div>
                    <?php    }
                }
                ?>

                <b style="color: #c82333">
                    الرجاء عمل مسح لل QR  لعرض النسخة الاصلية من الشهادة او ادخال رقم الشهادة هنا :
                </b>
                <div class="form-group">
                    <label for="username">رقم الشهادة</label>
                    <input type="text" maxlength="50" name="holderid" value="<?php if(isset($_POST['holderid'])){ echo $_POST['holderid'];} ?>" class="form-control" aria-describedby="emailHelp">
                </div>
                <button type="submit" class="btn btn-primary" name="login">التحقق</button>
            </form>
        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->
</div>
<!-- /.container -->

<?php include "template/footer.php"; ?>
