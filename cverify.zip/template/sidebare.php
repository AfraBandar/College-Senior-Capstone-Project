<div class="col-lg-3" dir="rtl" style="text-align: right">

    <h1 class="my-4">العمليات</h1>
    <div class="list-group">
        <?php
        if($_SESSION['type'] == 'admin'){
            ?>
            <a href="admin_manage.php" class="list-group-item">ادارة الجامعات</a>
        <?php }elseif($_SESSION['type'] == 'holder'){ ?>
            <a href="student_certificate.php" class="list-group-item">عرض الشهادات</a>
        <?php }else{ ?>
            <a href="certificate.php" class="list-group-item">ادارة الشهادات</a>
        <?php } ?>
		 <a href="admin_profile.php" class="list-group-item">بيانات الحساب</a>

        <a href="logout.php" class="list-group-item">تسجيل الخروج</a>
    </div>
	
	<style>
	
	.container
	{
		max-width: 100% !important;
	}
	
	</style>

</div>