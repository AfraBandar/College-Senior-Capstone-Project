<?php
include "template/header.php";
if(isset($_POST['login'])){
    $form =1;
    $type = '';
    $user_id = '';
    $types = array('holder','university','admin');
    if(isset($_POST['type']) && !empty(trim($_POST['type']))){
        $type = trim($_POST['type']);
        if(in_array($type,$types)){
            if($type == 'admin'){
                $table = 'admin';
                $user_id = 'adminid';
            }elseif ($type == 'holder'){
                $table = 'holder';
                $user_id = 'holderid';
            }else{
                $table = 'institute';
                $user_id = 'instituteid';
            }
        }else{
            $form =0;
            $errors['type'] = 'يرجى اختيار احد المستخدمين (طالب ,جامعه ,مدير النظام)';
        }
    }else{
        $form =0;
        $errors['type'] = 'حقل نوع المستخدم إلزامي';
    }

    if(isset($_POST['username']) && !empty(trim($_POST['username']))){
        $username = trim($_POST['username']);
    }else{
        $form =0;
        $errors['username'] = 'حقل اسم المستخدم إلزامي';
    }

    if(isset($_POST['password']) && !empty(trim($_POST['password']))){
        $password = trim($_POST['password']);
    }else{
        $form =0;
        $errors['password'] = 'حقل كلمة المرور إلزامي';
    }
    if($form == 1){
        $sql = "SELECT * FROM `$table` where password='$password' and username='$username'  LIMIT 1";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                if($table == 'institute'){
                   if($row['status'] == 0){
                       $errors['admin'] = 'لم يتم تفعيل الحساب من قبل مدير النظام';
                   }elseif($row['status'] == 2){
                       $errors['admin'] = 'تم رفض طلب تفعيل الحساب من قبل مدير النظام';
                   }else{
                       $_SESSION['user_id'] = $row[$user_id];
                       $_SESSION['type'] = $table;
                       header('location:index.php');
                       exit();
                   }
                }else{
                    $_SESSION['user_id'] = $row[$user_id];
                    $_SESSION['type'] = $table;
                    header('location:index.php');
                    exit();
                }
            }

        } else {
            $form = 1;
            $errors['login'] = 'خطأ في بيانات الدخول';
        }
    }
}
include "template/navbar.php";
?>

<!-- Page Content -->
<div class="container">

    <div class="row mt-5">
        <div class="col-lg-3"></div>
        <div class="col-lg-6" dir="rtl" style="text-align: right">
            <h3 class="title_form" style="text-align: center">تسجيل الدخول</h3>
            <form action="" method="post" id="form1">
                <?php
                if(isset($errors)){
                    foreach ($errors as $error){ ?>
                        <div class="alert alert-danger">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong></strong> <?php echo $error; ?>
                        </div>
                    <?php    }
                }
                ?>

                <div class="form-group" style="width: 100%">
                    <label for="exampleInputEmail1" class="text-dark font-weight-bold">نوع المستخدم</label>
                    <select  class="form-control" dir="rtl" name="type">
                        <option  value="holder" <?php if(isset($_POST['type'])){
                            if($_POST['type'] == 'holder'){
                                echo 'selected';
                            }
                        } ?>>طالب</option>
                        <option value="university" <?php if(isset($_POST['type'])){
                            if($_POST['type'] == 'university'){
                                echo 'selected';
                            }
                        } ?>>جامعه</option>
                        <option value="admin" <?php if(isset($_POST['type'])){
                            if($_POST['type'] == 'admin'){
                                echo 'selected';
                            }
                        } ?>>مدير النظام</option>

                    </select>
                </div>

                <div class="form-group">
                    <label for="username">اسم المستخدم</label>
                    <input type="text" maxlength="20" name="username" value="<?php if(isset($_POST['username'])){ echo $_POST['username'];} ?>" class="form-control" data-prompt-position="topLeft" id="username" aria-describedby="emailHelp">
                </div>
                <div class="form-group">
                    <label for="password">كلمة المرور</label>
                    <input type="password" maxlength="20" name="password" class="form-control" data-prompt-position="topLeft" id="password" aria-describedby="emailHelp">
                </div>
                <a href="register_as.php" style="color: #1a7ffb">
                    لا املك حساب سجل من هنا
                </a>
                <br>
                <a href="forget.php" style="color: #1a7ffb">نسيت كلمة المرور</a>
                <br>
                <br>
                <button type="submit" class="btn btn-primary" name="login">تسجيل الدخول</button>
            </form>
        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->
</div>
<!-- /.container -->

<?php include "template/footer.php"; ?>
