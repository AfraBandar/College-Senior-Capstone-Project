<?php
include 'include/connections.php';
if((!isset($_GET['id']) || empty($_GET['id'])) || (!isset($_GET['status']) || empty($_GET['status']))){
    header('location:admin_manage.php');
    exit();
}else{
    $id =$_GET['id'];
    $status = $_GET['status'];
    $sql = "update `institute` set status=$status WHERE instituteid=$id";
    if ($conn->query($sql) == TRUE) {
        header('location:admin_manage.php');
        exit();
    } else {
        die ("Error: " . $sql . "<br>" . $conn->error);
    }

}