<?php
include "template/header.php";
include('phpqrcode/qrlib.php');
if(!isset($_SESSION['type']) || ($_SESSION['type'] != 'holder')){
    header('location:index.php');
    exit();
}

if(!isset($_GET['id']) || empty(trim($_GET['id']))){
    header('location:certificate.php');
    exit();
}
$id = trim($_GET['id']);
include "template/navbar.php";
?>

<!-- Page Content -->
<div class="container">

    <div class="row">
        <!-- /.col-lg-3 -->
        <div class="col-lg-9" style="margin-top: 36px">
            <h3 class="title_form" style="text-align: center">تفاصيل الشهادة</h3>
            <div class="blog-single gray-bg">
                <?php

                $sql = "select * from `certificate` where `certificateid`=$id limit 1";
                $result = $conn->query($sql);
                if($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                ?>
                <div class="container">
                    <div class="row align-items-start">
                        <div class="col-lg-12 m-15px-tb" dir="rtl" style="text-align: right">
                            <article class="article">
                                <div class="article-img">
                                    <img src="images/<?php echo $row['photo']; ?>" width="800px" height="350px" title="" alt="">
                                </div>
                                <div class="article-content mt-3">
                                    <h4>
                                        <?php echo $row['title']; ?>
                                    </h4>
                                    <p>
                                        <?php echo $row['details']; ?>
                                    </p>
                                    <ul>
                                        <li>حامل الشهادة : <?php echo $row['holdername']; ?></li>
                                        <li>السجل المدني : <?php echo $row['holderid']; ?></li>
                                        <li>التاريخ : <?php echo $row['date']; ?></li>
                                    </ul>
                                    <blockquote>
                                        <p class="blockquote-footer"> <cite title="Source Title">
                                                <a href="images/<?php echo $row['photo']; ?>" download=""> تنزيل الشهادة </a>
                                            </cite></p>
                                    </blockquote>
                                </div>
                            </article>
                        </div>
                    </div>
                </div>
                <?php }} ?>
            </div>
        </div>
        <?php include "template/sidebare.php"; ?>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->
</div>
<!-- /.container -->

<?php include "template/footer.php"; ?>
