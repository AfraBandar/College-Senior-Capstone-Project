<?php
include "template/header.php";
if (isset($_POST['register'])) {
    $table = 'holder';
    $errors = array();
    $fields = array('السجل المدني'=>'holderid','الإسم' => 'name', 'الجوال' => 'mobile', 'البريد الالكتروني' => 'email', 'اسم المستخدم' => 'username', 'كلمة المرور' => 'password', 'تأكيد كلمة المرور' => 'password_confirm','تاريخ الميلاد'=>'birthdate');
    foreach ($fields as $key=>$field){
        if (!isset($_POST[$field]) || empty(trim($_POST[$field]))) {
            $errors[$field] = "  الرجاء ادخال $key";
        }
    }

    $name = mysqli_real_escape_string($conn, trim($_POST['name']));

    //check mobile
    if (isset($_POST['mobile']) && !empty(trim($_POST['mobile']))) {
        $mobile = mysqli_real_escape_string($conn, trim($_POST['mobile']));
        if(strlen($mobile) != 10){
            $errors['mobile'] = 'رقم الجوال يجب ان يحتوي على 10 ارقام';
        } elseif (!check_mobile_exist($mobile, $table)) {
            $errors['mobile'] = 'رقم الجوال موجود مسبقا';
        }elseif(!check_mobile($mobile)){
            $errors['mobile'] = 'خطا في رقم الجوال';
        }
    }

    //validation email
    if (isset($_POST['email']) && !empty(trim($_POST['email']))) {
        $email = mysqli_real_escape_string($conn, trim($_POST['email']));
        if (!check_email_exist($email, $table)) {
            $errors['email'] = 'البريد الالكتروني موجود مسبقا';
        }elseif(! valid_email($email)){
            $errors['email'] = 'البريد الالكتروني غير صالح';
        }
    }

    //check if exist
    if (isset($_POST['username']) && !empty(trim($_POST['username']))) {
        $username = mysqli_real_escape_string($conn, trim($_POST['username']));
        if (!check_user_exist($username, $table)) {
            $errors['username'] = 'اسم المستخدم موجود مسبقا';
        }elseif (strlen($username) > 30){
            $errors['username'] = 'اسم المستخدم يجب ان لا يزيد عن 30 حرف';
        }
    }
    //check holderid
    if (isset($_POST['holderid']) && !empty(trim($_POST['holderid']))) {
        $holderid = mysqli_real_escape_string($conn, trim($_POST['holderid']));
        if (!check_holder_exist($holderid, $table)) {
            $errors['holderId'] = 'السجل المدني موجود مسبقا';
        }elseif(! check_mobile($holderid)){
            $errors['holderId'] = 'السجل المدني يجب يحتوي على ارقام فقط';
        }elseif (strlen($holderid) != 10){
            $errors['holderId'] = 'السجل المدني يجب ان يحتوي على 10 ارقام';
        }
    }

    $password = '';
    if (isset($_POST['password']) && !empty(trim($_POST['password']))) {
        $password = mysqli_real_escape_string($conn, trim($_POST['password']));
        if(strlen($password) < 6){
            $errors['password'] = 'كلمة المرور يجب ان لا تقل عن 6 احرف';
            $password = '';
        }
    }
    $password_conf = mysqli_real_escape_string($conn,trim($_POST['password_confirm']));
    if(!empty($password) && !empty($password_conf)){
        if($password != $password_conf){
            $errors['password'] = 'كلمة المرور غير متطابقة';
        }
    }

    //validation date
    $dateNow = date('Y-m-d');
    if(isset($_POST['birthdate']) && !empty(trim($_POST['birthdate']))){
        $birthdate = mysqli_real_escape_string($conn, trim($_POST['birthdate']));
        $checkDateArr = explode('-',$birthdate);
        if(count($checkDateArr) != 3){
            $errors['birthDate'] = 'يرجى التحقق من تاريخ الميلاد';
        }else{
            if(!checkdate($checkDateArr[1],$checkDateArr[2],$checkDateArr[0])){
                $errors['birthDate'] = 'يرجى التحقق من تاريخ الميلاد';
            }else{
                if($dateNow <= $birthdate){
                    $errors['birthDate'] = 'يرجى التحقق من تاريخ الميلاد';
                }
            }
        }
    }




    if (empty($errors)) {
        $sql = "INSERT INTO `$table` (`holderid`,`name`, `mobile`,`email`,`username`,`password`,`birthdate`)"
            . " VALUES ('$holderid','$name','$mobile','$email','$username','$password','$birthdate')";
        if ($conn->query($sql) == TRUE) {
            $_SESSION['user_id'] = $holderid;
            $_SESSION['type'] = $table;
            header("location:index.php");
            exit();
        } else {
            echo $conn->error . '<br>';
            echo $sql;
        }
    }
}
include "template/navbar.php";
?>

<!-- Page Content -->
<div class="container">

    <div class="row mt-5">
        <div class="col-lg-3"></div>
        <div class="col-lg-6" dir="rtl" style="text-align: right">
            <h3 class="title_form" style="text-align: center">انشاء حساب جديد (طالب)</h3>
            <form action="" method="post">
                <?php
                if(isset($errors)){
                    foreach ($errors as $error){ ?>
                        <div class="alert alert-danger">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong></strong> <?php echo $error; ?>
                        </div>
                    <?php    }
                }
                ?>
                <div class="form-group">
                    <label for="mobile">السجل المدني</label>
                    <input type="text"  onkeypress="return isNumberKey(event)" maxlength="10" value="<?php if(isset($_POST['holderid'])){ echo $_POST['holderid'];} ?>" name="holderid" class="form-control">
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">الاسم</label>
                    <input type="text" maxlength="30" name="name" value="<?php if(isset($_POST['name'])){ echo $_POST['name'];} ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">البريد الالكتروني</label>
                    <input type="email" maxlength="30" name="email" value="<?php if(isset($_POST['email'])){ echo $_POST['email'];} ?>" class="form-control">
                </div>
                <div class="row">
                    <div class="col">
                <div class="form-group">
                    <label for="mobile">الجوال</label>
                    <input type="text"  onkeypress="return isNumberKey(event)" maxlength="10" value="<?php if(isset($_POST['mobile'])){ echo $_POST['mobile'];} ?>" name="mobile" class="form-control">
                </div>
                    </div>
                    <div class="col">
                <div class="form-group">
                    <label>تاريخ الميلاد</label>
                    <input type="date"  value="<?php if(isset($_POST['birthdate'])){ echo $_POST['birthdate'];} ?>" name="birthdate" class="form-control" style="text-align: right">
                </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="username">اسم المستخدم</label>
                    <input type="text" maxlength="15" name="username" value="<?php if(isset($_POST['username'])){ echo $_POST['username'];} ?>" class="form-control">
                </div>

                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label for="password">كلمة المرور</label>
                            <input type="password" maxlength="15" name="password" class="form-control"  id="password">
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label for="password_confirm">تأكيد كلمة المرور</label>
                            <input type="password" maxlength="15" name="password_confirm"  class="form-control">
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary" name="register">تسجيل</button>
            </form>
        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->
</div>
<!-- /.container -->

<?php include "template/footer.php"; ?>
