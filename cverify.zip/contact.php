<?php
include "template/header.php";
include "template/navbar.php";
?>

<!-- Page Content -->
<div class="container">


    <div class="aboutus-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12" dir="rtl" style="text-align: right">
                    <h3 class="title_form" style="text-align: center">تواصل معنا</h3>
                    <section id="contact">
                        <div class="container">
                            <div class="row">
                                <div class="col-sm-12 col-md-6 col-lg-6 my-5">
                                    <div class="card border-0">
                                        <div class="card-body text-center">
                                            <i class="fa fa-phone fa-5x mb-3" aria-hidden="true"></i>
                                            <h4 class="text-uppercase mb-5">الاتصال</h4>
                                            <p>+8801683615582,+8801750603409</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-6 col-lg-6 my-5">
                                    <div class="card border-0">
                                        <div class="card-body text-center">
                                            <i class="fa fa-globe fa-5x mb-3" aria-hidden="true"></i>
                                            <h4 class="text-uppercase mb-5">البريد الالكتروني</h4>
                                            <p>verify@gmail.com</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
    <!-- /.row -->
    <!-- /.row -->


    <!-- /.row -->
</div>
<!-- /.container -->

<?php include "template/footer.php"; ?>

