<?php
include "template/header.php";
include "template/navbar.php";
?>

<!-- Page Content -->
<div class="container" dir="rtl">

    <div class="row no-gutters mt-5" style="margin-top: 74px !important;">
        <div class="col-lg-1"></div>
        <div class="col-lg-4" >
            <img src="university.png" style="width: 300px;height: 300px;">
            <h3 id="register-title">
                <a href="register_ins.php">
                    التسجيل كجامعة
                </a>
            </h3>
        </div>
        <div class="col-lg-1"></div>
        <div class="col-lg-4">
            <img src="student.png" style="width: 300px;height: 300px;">
            <h3 id="register-title">
                <a href="register.php">
                    التسجيل كطالب
                </a>
            </h3>
        </div>
    </div>

</div>
<!-- /.container -->

<?php include "template/footer.php"; ?>

