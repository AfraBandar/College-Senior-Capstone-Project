<?php
include "template/header.php";
include "template/navbar.php";
?>

<!-- Page Content -->
<div class="container">


     <div class="aboutus-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12" dir="rtl" style="text-align: right">
                            <h3 class="title_form" style="text-align: center">حول الموقع</h3>
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="aboutus-image float-left hidden-sm"><img src="security.jpg" alt=""></div>
                            </div>
                            <div class="col-md-12 col-sm-6 col-xs-12">
                                <div class="aboutus-content ">
                                    <h1> <span>Verify</span></h1>
                                    <h4>التحقق</h4>
                                    <p>
                                        يقوم الموقع من التحقق من الشهادات من خلال QR او رقم الشهادة
                                    </p>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
    <!-- /.row -->


    <!-- /.row -->
</div>
<!-- /.container -->

<?php include "template/footer.php"; ?>

