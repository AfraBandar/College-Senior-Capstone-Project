<?php
include "template/header.php";
include('phpqrcode/qrlib.php');
if(!isset($_SESSION['type']) || ($_SESSION['type'] != 'institute')){
    header('location:index.php');
    exit();
}

function watermark_image($target, $wtrmrk_file, $newcopy,$ext,$string) {

    $watermark = imagecreatefrompng($wtrmrk_file);
    imagealphablending($watermark, false);
    imagesavealpha($watermark, true);

    if($ext == 'png'){
        $img = imagecreatefrompng($target);
    }else{
        $img = imagecreatefromjpeg($target);
    }
    $img_w = imagesx($img);
    $img_h = imagesy($img);

    $wtrmrk_w = imagesx($watermark);
    $wtrmrk_h = imagesy($watermark);
    //$dst_x = ($img_w / 2) - ($wtrmrk_w / 2); // For centering the watermark on any image
    //$dst_y = ($img_h / 2) - ($wtrmrk_h / 2); // For centering the watermark on any image
    $margin_right = 10;
    $margin_bottom = 10;
    $dst_x = imagesx($img) - $wtrmrk_w - $margin_right;
    $dst_y = imagesy($img) - $wtrmrk_h - $margin_bottom;

    $color = imagecolorallocate($img, 0, 0, 0);
    $string = $string;
    $fontSize =1000;
    imagestring($img, $fontSize, 0, 0, $string, $color);

    //imagettftext($img,  20, 0, 10, $img_h, $color, 'arial.ttf', $string);

    imagecopy($img, $watermark, $dst_x, $dst_y, 0, 0, $wtrmrk_w, $wtrmrk_h);
    if($ext == 'png') {
        imagepng($img, $newcopy);
    }else {
        imagejpeg($img, $newcopy);
    }
    imagedestroy($img);
    imagedestroy($watermark);
}

if (isset($_POST['register'])) {
    $table = 'certificate';
    $errors = array();
    $fields = array('العنوان' => 'title', 'الوصف' => 'details','النوع'=>'type','التاريخ'=>'date','السجل المدني'=>'holderid','حامل الشهادة'=>'holdername');
    foreach ($fields as $key=>$field){
        if (!isset($_POST[$field]) || empty(trim($_POST[$field]))) {
            $errors[$field] = "حقل $key مطلوب";
        }
    }

    $title = mysqli_real_escape_string($conn, trim($_POST['title']));
    $details = mysqli_real_escape_string($conn, trim($_POST['details']));
    $type = mysqli_real_escape_string($conn, trim($_POST['type']));
    $date = mysqli_real_escape_string($conn, trim($_POST['date']));
    $holdername = mysqli_real_escape_string($conn, trim($_POST['holdername']));

    //check holderid
    if (isset($_POST['holderid']) && !empty(trim($_POST['holderid']))) {
        $holderid = mysqli_real_escape_string($conn, trim($_POST['holderid']));
        if(! check_mobile($holderid)){
            $errors['holderId'] = 'السجل المدني يجب يحتوي على ارقام فقط';
        }elseif (strlen($holderid) != 10){
            $errors['holderId'] = 'السجل المدني يجب ان يحتوي على 10 ارقام';
        }
    }



    $filename = '';
    $filename2 = '';
    $stringSerial = date('Yi').getNameRand(6);
        if (!empty($_FILES['picture']['name'])) {
            if(empty($errors)) {
                $tmp_file = $_FILES['picture']['tmp_name'];
                $filename = $_FILES['picture']['name'];
                $ext = explode('.', $filename);
                $extention = end($ext);
                $filename = str_replace(' ', '_', $filename);
                $filename = date('Ymdis') . '.' . $extention;
                $filename2 = date('Ymdis') . '.' . $extention;
                $upload = "images/";
                if (($_FILES['picture']['type'] == 'image/jpeg') || ($_FILES['picture']['type'] == 'image/jpg') || ($_FILES['picture']['type'] == 'image/png')) {
                    if (empty($errors)) {
                        if ((move_uploaded_file($tmp_file, $upload . $filename)) == 1) {
                            $codeContents = $stringSerial;
                            $fileQr = "$stringSerial.png";
                            $pngAbsoluteFilePath = "images/" . $fileQr;
                            if (!file_exists($pngAbsoluteFilePath)) {
                                QRcode::png($codeContents, $pngAbsoluteFilePath);
                                $originFile = $filename;
                                $copyFile = $filename2;
                                watermark_image('images/' . $originFile, $pngAbsoluteFilePath, 'images/' . $copyFile, $extention,$stringSerial);
                            } else {
                                $errors['image'] = 'please try again';
                            }

                        }
                    } else {
                    }
                } else {
                    $form = 0;
                    $errors['image_re'] = 'امتداد الصورة يجب ان يكون  (jpeg,jpg,png)';
                }
            }
        } else {
            $errors['image_re'] = 'حقل الصورة مطلوب';
        }



    if (empty($errors)) {
        $user_id = $_SESSION['user_id'];
        $sql = "INSERT INTO `$table` (`title`, `details`,`date`,`type`,`holdername`,`holderid`,`photo`,`serial_code`,`instituteid`)"
            . " VALUES ('$title','$details','$date','$type','$holdername','$holderid','$filename2','$stringSerial','$user_id')";
        if ($conn->query($sql) == TRUE) {
            header("location:certificate.php");
            exit();
        } else {
            echo $conn->error . '<br>';
            echo $sql;
        }
    }
}

include "template/navbar.php";
?>

<!-- Page Content -->
<div class="container">

    <div class="row">
        <!-- /.col-lg-3 -->
        <div class="col-lg-9" style="margin-top: 36px">
            <h3 class="title_form" style="text-align: center">اضافة شهادة</h3>
            <form action="" method="post" dir="rtl" style="text-align: right" enctype="multipart/form-data">
                <?php
                if(isset($errors)){
                    foreach ($errors as $error){ ?>
                        <div class="alert alert-danger">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>خطأ!</strong> <?php echo $error; ?>
                        </div>
                    <?php    }
                }
                ?>
                <div class="form-group">
                    <label for="exampleInputEmail1">العنوان</label>
                    <input type="text" maxlength="100" name="title" value="<?php if(isset($_POST['title'])){ echo $_POST['title'];} ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">الوصف</label>
                    <textarea maxlength="500" name="details" class="form-control" rows="5"><?php if(isset($_POST['details'])){ echo $_POST['details'];} ?></textarea>
                </div>

                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label for="mobile">النوع</label>
                            <select name="type" class="form-control">
                                <option value=""> -- اختيار النوع --</option>
                                <?php
                                $types = get_type();
                                foreach ($types as $type){
                                    ?>
                                    <option value="<?php echo $type ?>"
                                    <?php
                                    if(isset($_POST['type'])){
                                        if($_POST['type'] == $type){
                                            echo  ' selected';
                                        }
                                    }
                                    ?>
                                    ><?php echo $type ?></option>
                                    <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label>التاريخ</label>
                            <input type="date"  value="<?php if(isset($_POST['date'])){ echo $_POST['date'];} ?>" name="date" class="form-control" style="text-align: right">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label for="password">السجل المدني</label>
                            <input type="text" onkeypress="return isNumberKey(event)" maxlength="10" name="holderid" class="form-control"  value="<?php if(isset($_POST['holderid'])){echo $_POST['holderid']; } ?>">
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label for="password_confirm">حامل الشهادة</label>
                            <input type="text" maxlength="50" name="holdername"  class="form-control" value="<?php if(isset($_POST['holdername'])){echo $_POST['holdername']; } ?>" >
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label >الصورة</label>
                    <input maxlength="100" type="file" name="picture" class="form-control" data-prompt-position="topLeft">
                </div>
                <button type="submit" class="btn btn-primary" name="register">اضافة</button>
            </form>
        </div>
        <?php include "template/sidebare.php"; ?>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->
</div>
<!-- /.container -->

<?php include "template/footer.php"; ?>
