<?php
include "template/header.php";
if(isset($_POST['register'])){
    if(isset($_POST['email'])){
        $email = mysqli_real_escape_string($conn,trim($_POST['email']));
        if(! valid_email($email)){
            $errors['email'] = 'البريد الالكتروني غير صالح';
        }else{
            $success = 'لقد تم ارسال كلمة مرور جديدة الى بريدك الالكتروني';
        }
    }
    else{
        $errors['email'] = 'حقل كلمة المرور مطلوبة';
    }
    if(empty($errors)){
        $success = 'لقد تم ارسال كلمة المرور الجديدة الى بريدك الالكتروني';
    }
}
include "template/navbar.php";
?>

<!-- Page Content -->
<div class="container">

    <div class="row mt-5">
        <div class="col-lg-3"></div>
        <div class="col-lg-6" dir="rtl" style="text-align: right">
            <h3 class="title_form" style="text-align: center">الحصول على كلمة مرور جديدة</h3>
            <form action="" method="post">
                <?php
                if(isset($errors)){
                    foreach ($errors as $error){ ?>
                        <div class="alert alert-danger">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>خطأ!</strong> <?php echo $error; ?>
                        </div>
                    <?php    }
                }
                ?>
                <?php
                if(isset($success)){
                    ?>
                    <div class="alert alert-success">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>صحيح!</strong> <?php echo $success; ?>
                    </div>
                    <?php
                }
                ?>


                <div class="form-group">
                    <label for="exampleInputPassword1" class="text-dark font-weight-bold">البريد الالكتروني</label>
                    <input type="email" name="email" class="form-control" maxlength="30" id="exampleInputPassword1" placeholder="ادخل البريد الالكتروني">
                </div>
                <button type="submit" class="btn btn-primary" name="register">ارسال</button>
            </form>
        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->
</div>
<!-- /.container -->

<?php include "template/footer.php"; ?>
