<?php
include "template/header.php";
if(!isset($_SESSION['type']) || ($_SESSION['type'] != 'admin')){
    header('location:index.php');
    exit();
}
include "template/navbar.php";
?>

<!-- Page Content -->
<div class="container">

    <div class="row">
        <!-- /.col-lg-3 -->
        <div class="col-lg-9" style="margin-top: 36px">
            <h3 class="title_form" style="text-align: center">ادارة الجامعات</h3>
            <table class="table"  dir="rtl" style="text-align: right">
                <thead class="thead-dark">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">صورة</th>
                    <th scope="col">الجامعة</th>
                    <th scope="col">البريد الالكتروني</th>
                    <th scope="col">الجوال</th>
                    <th scope="col">الحالة</th>
                    <th scope="col">العمليات</th>
                </tr>
                </thead>
                <tbody>
                <?php

                $sql = "select * from `institute`";
                $cnt =1;
                $result = $conn->query($sql);
                if($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                ?>
                <tr>
                    <th scope="row"><?php $cnt++; ?></th>
                    <td>
                        <img src="images/<?php echo $row['photo']; ?>" width="50px" height="50px">
                    </td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['mobile']; ?></td>
                    <td>
                        <?php
                        if($row['status'] == 0){
                            ?>
                            <a  class="btn btn-warning">في حالة انتظار</a>
                            <?php
                        }elseif ($row['status'] == 1){
                        ?>
                            <a  class="btn btn-success">تم الموافقة</a>
                            <?php
                        }elseif ($row['status'] == 2){
                        ?>
                            <a  class="btn btn-danger">تم الرفض</a>
                                <?php } ?>
                    </td>
                    <td>
                        <?php
                        if($row['status'] == 0){
                            ?>
                            <a href="admin_manage_status.php?id=<?php echo $row['instituteid']; ?>&status=2" class="btn btn-danger" onclick="return confirm('هل انت متأكد من الرفض ؟')">رفض</a>
                            <a href="admin_manage_status.php?id=<?php echo $row['instituteid']; ?>&status=1" class="btn btn-success" onclick="return confirm('هل انت متأكد من الموافقة؟')">موافقة</a>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
                <?php }} ?>
                </tbody>
            </table>
        </div>
        <?php include "template/sidebare.php"; ?>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->
</div>
<!-- /.container -->

<?php include "template/footer.php"; ?>
