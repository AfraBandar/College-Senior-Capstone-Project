<?php
include "template/header.php";
if(!isset($_SESSION['type']) || ($_SESSION['type'] != 'holder')){
    header('location:index.php');
    exit();
}
include "template/navbar.php";
?>

<!-- Page Content -->
<div class="container">

    <div class="row">
        <!-- /.col-lg-3 -->
        <div class="col-lg-9" style="margin-top: 36px">
            <h3 class="title_form" style="text-align: center"> الشهادات</h3>
            <table class="table"  dir="rtl" style="text-align: right">
                <thead class="thead-dark">
                <tr>
                    <th scope="col">الصورة</th>
                    <th scope="col">العنوان</th>
                    <th scope="col">الوصف</th>
                    <th scope="col">النوع</th>
                    <th scope="col">التاريخ</th>
                    <th scope="col">حامل الشهادة</th>
                    <th scope="col">رقم الشهادة</th>
                    <th scope="col">تنزيل الشهادة</th>
                    <th>التفاصيل</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $user_id = $_SESSION['user_id'];
                $sql = "select * from `certificate` where holderid='$user_id'";
                $cnt =1;
                $result = $conn->query($sql);
                if($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        ?>
                        <tr>
                            <td>
                                <img src="images/<?php echo $row['photo']; ?>" width="50px" height="50px">
                            </td>
                            <td><?php echo $row['title']; ?></td>
                            <td>
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal<?php echo $row['certificateid']; ?>">
                                    الوصف
                                </button>
                            </td>
                            <td><?php echo $row['type']; ?></td>
                            <td><?php echo $row['date']; ?></td>
                            <td><?php echo $row['holdername']; ?></td>
                            <td><?php echo $row['serial_code']; ?></td>
                            <td>
                                <a href="images/<?php echo $row['photo']; ?>" download=""> تنزيل الشهادة </a>
                            </td>
                            <td>
                                <a href="certificate_details.php?id=<?php echo $row['certificateid']; ?>" class="btn btn-primary"> التفاصيل </a>
                            </td>

                            <div class="modal fade" id="exampleModal<?php echo $row['certificateid']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel" style="width: 100%;text-align: right;">الوصف</h5>
                                            <button style="text-align: left" type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body" style="text-align: right">
                                            <?php echo $row['details']; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </tr>
                    <?php }} ?>
                </tbody>
            </table>
        </div>
        <?php include "template/sidebare.php"; ?>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->
</div>
<!-- /.container -->

<?php include "template/footer.php"; ?>
