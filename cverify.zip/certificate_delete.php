<?php
include 'include/connections.php';
if(!isset($_GET['id']) || empty($_GET['id'])){
    header('location:certificate.php');
    exit();
}else{
    $id =$_GET['id'];
    $sql = "delete from `certificate` WHERE certificateid=$id";
    if ($conn->query($sql) == TRUE) {
        header('location:certificate.php');
        exit();
    } else {
        die ("Error: " . $sql . "<br>" . $conn->error);
    }

}